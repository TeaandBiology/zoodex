import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../data/reference_data.dart';
import '../data/visit_store.dart';
import '../models/dex_entry.dart';
import '../models/species.dart';
import '../util/date_format.dart';
import '../widgets/count_badge.dart';
import '../widgets/iucn_tag.dart';
import '../widgets/species_image.dart';
import 'species_detail_screen.dart';
import 'tree_view.dart';

enum _SortField {
  taxonomy('Taxonomy'),
  firstObserved('First observed'),
  alphabetical('Alphabetical'),
  totalSeen('Total number seen'),
  iucn('IUCN status');

  const _SortField(this.label);
  final String label;
}

typedef _Row = ({Species species, DexEntry dex});

enum _ViewMode { list, grid, tree }

class ZooDexScreen extends StatefulWidget {
  const ZooDexScreen({super.key});

  @override
  State<ZooDexScreen> createState() => _ZooDexScreenState();
}

class _ZooDexScreenState extends State<ZooDexScreen> {
  String _query = '';
  _ViewMode _view = _ViewMode.list;
  String? _groupFilter; // null = all groups
  _SortField _sort = _SortField.firstObserved;
  bool _asc = false; // false = descending

  /// All logged species (unfiltered, unsorted).
  List<_Row> _allRows() {
    final ref = ReferenceData.instance;
    final rows = <_Row>[];
    for (final e in VisitStore.buildDex(rollUp: true)) {
      final s = ref.speciesById(e.speciesId);
      if (s == null) continue; // species no longer in catalog
      rows.add((species: s, dex: e));
    }
    return rows;
  }

  String _zoosLabel(DexEntry e) {
    final ref = ReferenceData.instance;
    final names = e.zoosSeenAt.map((id) => ref.zooById(id)?.name ?? id).toList()
      ..sort();
    return names.join(', ');
  }

  // Full taxonomic path (kingdom -> species) as a sortable key.
  String _taxonKey(Species s) => TaxonRank.values
      .map((r) => (s.taxonomy.valueFor(r) ?? '').toLowerCase())
      .join('\u0001');

  int _compare(_Row a, _Row b) {
    int cmp;
    switch (_sort) {
      case _SortField.taxonomy:
        cmp = _taxonKey(a.species).compareTo(_taxonKey(b.species));
      case _SortField.firstObserved:
        final da = a.dex.firstSeenAt ?? DateTime.fromMillisecondsSinceEpoch(0);
        final db = b.dex.firstSeenAt ?? DateTime.fromMillisecondsSinceEpoch(0);
        cmp = da.compareTo(db);
      case _SortField.alphabetical:
        cmp = a.species.commonName
            .toLowerCase()
            .compareTo(b.species.commonName.toLowerCase());
      case _SortField.totalSeen:
        cmp = a.dex.visitsSeenCount.compareTo(b.dex.visitsSeenCount);
      case _SortField.iucn:
        // Higher rank = rarer; with descending (default) the rarest sort first.
        cmp = iucnRarityRank(a.species.iucnStatus)
            .compareTo(iucnRarityRank(b.species.iucnStatus));
    }
    // Stable tiebreak so equal keys keep a predictable order.
    if (cmp == 0) {
      cmp = a.species.commonName
          .toLowerCase()
          .compareTo(b.species.commonName.toLowerCase());
    }
    return _asc ? cmp : -cmp;
  }

  void _openDetail(_Row r) {
    final e = r.dex;
    final zooId =
        e.lastZooId ?? (e.zoosSeenAt.isNotEmpty ? e.zoosSeenAt.first : '');
    final zooName = ReferenceData.instance.zooById(zooId)?.name;
    Navigator.of(context).pushNamed(
      '/detail',
      arguments: SpeciesDetailArgs(
        zooId: zooId,
        zooName: zooName,
        species: r.species,
        interactive: false,
      ),
    );
  }

  void _openSortSheet() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (sheetContext, setSheet) {
            void apply(VoidCallback fn) {
              setState(fn);
              setSheet(() {});
            }

            return SafeArea(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                    child: Text('Sort by',
                        style: Theme.of(sheetContext).textTheme.titleMedium),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: SegmentedButton<bool>(
                      segments: const [
                        ButtonSegment(value: true, label: Text('Ascending')),
                        ButtonSegment(value: false, label: Text('Descending')),
                      ],
                      selected: {_asc},
                      onSelectionChanged: (s) => apply(() => _asc = s.first),
                    ),
                  ),
                  const SizedBox(height: 8),
                  for (final f in _SortField.values)
                    ListTile(
                      title: Text(f.label),
                      selected: _sort == f,
                      trailing: _sort == f
                          ? Icon(_asc
                              ? Icons.arrow_upward
                              : Icons.arrow_downward)
                          : null,
                      onTap: () => apply(() => _sort = f),
                    ),
                  const SizedBox(height: 8),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Box>(
      valueListenable: VisitStore.listenable(),
      builder: (context, _, __) {
        final all = _allRows();

        // Groups present among logged species, in canonical order.
        final present = <String>{for (final r in all) r.species.majorGroup};
        final groupOptions = [
          ...Species.majorGroups.where(present.contains),
          ...present.where((g) => !Species.majorGroups.contains(g)).toList()
            ..sort(),
        ];

        final q = _query.trim().toLowerCase();
        var rows = all.where((r) {
          if (_groupFilter != null && r.species.majorGroup != _groupFilter) {
            return false;
          }
          if (q.isEmpty) return true;
          return r.species.commonName.toLowerCase().contains(q) ||
              r.species.scientificName.toLowerCase().contains(q) ||
              r.species.majorGroup.toLowerCase().contains(q) ||
              _zoosLabel(r.dex).toLowerCase().contains(q);
        }).toList()
          ..sort(_compare);

        return Scaffold(
          appBar: AppBar(
            title: Text('Species (${rows.length})'),
            actions: [
              IconButton(
                tooltip: 'Sort',
                icon: const Icon(Icons.sort),
                onPressed: _openSortSheet,
              ),
              PopupMenuButton<_ViewMode>(
                tooltip: 'View',
                icon: Icon(switch (_view) {
                  _ViewMode.list => Icons.view_list,
                  _ViewMode.grid => Icons.grid_view,
                  _ViewMode.tree => Icons.account_tree,
                }),
                onSelected: (m) => setState(() => _view = m),
                itemBuilder: (context) => [
                  CheckedPopupMenuItem(
                    value: _ViewMode.list,
                    checked: _view == _ViewMode.list,
                    child: const Text('List'),
                  ),
                  CheckedPopupMenuItem(
                    value: _ViewMode.grid,
                    checked: _view == _ViewMode.grid,
                    child: const Text('Grid'),
                  ),
                  CheckedPopupMenuItem(
                    value: _ViewMode.tree,
                    checked: _view == _ViewMode.tree,
                    child: const Text('Tree of life'),
                  ),
                ],
              ),
            ],
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
                child: TextField(
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'Search species, zoo, group…',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (v) => setState(() => _query = v),
                ),
              ),
              if (groupOptions.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
                  child: InputDecorator(
                    decoration: const InputDecoration(
                      labelText: 'Group',
                      border: OutlineInputBorder(),
                      isDense: true,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String?>(
                        isExpanded: true,
                        value: _groupFilter,
                        onChanged: (v) => setState(() => _groupFilter = v),
                        items: [
                          const DropdownMenuItem<String?>(
                            value: null,
                            child: Text('All groups'),
                          ),
                          for (final g in groupOptions)
                            DropdownMenuItem<String?>(
                              value: g,
                              child: Text(g),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              Expanded(
                child: rows.isEmpty
                    ? Center(
                        child: Text(
                            all.isEmpty ? 'No sightings yet.' : 'No matches.'))
                    : switch (_view) {
                        _ViewMode.list => _buildList(rows),
                        _ViewMode.grid => _buildGrid(rows),
                        _ViewMode.tree => TaxonomyTreeView(
                            species: [for (final r in rows) r.species],
                            onOpenSpecies: (sp) {
                              final m = rows
                                  .where((r) => r.species.id == sp.id);
                              if (m.isNotEmpty) _openDetail(m.first);
                            },
                          ),
                      },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildList(List<_Row> rows) {
    return ListView.separated(
      itemCount: rows.length,
      separatorBuilder: (_, _) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final r = rows[i];
        final e = r.dex;
        return ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          title: Row(
            children: [
              Expanded(
                child: Text(
                  r.species.commonName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (e.everVerified)
                const Padding(
                  padding: EdgeInsets.only(right: 6),
                  child: Icon(Icons.verified, size: 18),
                ),
              CountBadge(count: e.visitsSeenCount),
            ],
          ),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${r.species.scientificName} • ${r.species.majorGroup}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    _Pill(text: _zoosLabel(e)),
                    if (e.lastSeenAt != null)
                      Text(
                        'Last seen: ${formatLocalDate(e.lastSeenAt!)}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                  ],
                ),
              ],
            ),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _openDetail(r),
        );
      },
    );
  }

  Widget _buildGrid(List<_Row> rows) {
    const cross = 3;
    const radius = Radius.circular(12);
    final n = rows.length;
    final numRows = (n + cross - 1) ~/ cross;
    final lastRowStart = (numRows - 1) * cross;
    final lastRowFull = n % cross == 0;
    final firstRowLast = n < cross ? n - 1 : cross - 1;

    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      // A very thin gap between images; only the block's outer corners round.
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: cross,
        mainAxisSpacing: 2,
        crossAxisSpacing: 2,
        childAspectRatio: 1, // square cells
      ),
      itemCount: n,
      itemBuilder: (context, i) {
        final r = rows[i];
        // Round only the four outer corners of the whole grid. The bottom-right
        // is rounded only when the last row is full (otherwise it's ragged, so
        // just the bottom-left of the last row is rounded).
        final border = BorderRadius.only(
          topLeft: i == 0 ? radius : Radius.zero,
          topRight: i == firstRowLast ? radius : Radius.zero,
          bottomLeft: i == lastRowStart ? radius : Radius.zero,
          bottomRight: (lastRowFull && i == n - 1) ? radius : Radius.zero,
        );
        return _SpeciesGridCell(
          species: r.species,
          onTap: () => _openDetail(r),
          borderRadius: border,
        );
      },
    );
  }
}

class _SpeciesGridCell extends StatelessWidget {
  final Species species;
  final VoidCallback onTap;
  final BorderRadius borderRadius;
  const _SpeciesGridCell({
    required this.species,
    required this.onTap,
    required this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: borderRadius,
      child: Stack(
        fit: StackFit.expand,
        children: [
          SpeciesImage(species: species),
          // Shaded bar with the common name across the bottom.
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              color: Colors.black54,
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
              child: Text(
                species.commonName,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ),
          ),
          Positioned.fill(
            child: Material(
              type: MaterialType.transparency,
              child: InkWell(onTap: onTap),
            ),
          ),
        ],
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final String text;
  const _Pill({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(text, style: Theme.of(context).textTheme.labelMedium),
    );
  }
}
