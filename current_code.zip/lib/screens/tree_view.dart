import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/species.dart';

/// A "tree of life" of the observed species, drawn as a zoomable sunburst.
///
/// Hierarchy: major group -> order -> family -> genus -> species. The centre is
/// the current focus; each ring out is the next rank, with arc size proportional
/// to how many observed species sit under it. Tap an arc (or a row in the list
/// below) to zoom into that clade; tap the centre to zoom back out; or use the
/// breadcrumb. Tapping a species opens its page.
///
/// Built blind (no compiler here), so the interaction is deliberately simple and
/// robust — tap-to-drill rather than free pan/zoom/rotate.
class TaxonomyTreeView extends StatefulWidget {
  final List<Species> species;
  final void Function(Species species) onOpenSpecies;

  const TaxonomyTreeView({
    super.key,
    required this.species,
    required this.onOpenSpecies,
  });

  @override
  State<TaxonomyTreeView> createState() => _TaxonomyTreeViewState();
}

// --- Tree model ------------------------------------------------------------

class _Node {
  final String label;
  final int depth; // 0 root, 1 group, 2 order, 3 family, 4 genus, 5 species
  final String group; // major group, for colour
  final String? speciesId;
  final Species? species;
  int leaves = 0;
  final Map<String, _Node> children = {};

  _Node(this.label, this.depth, this.group, {this.speciesId, this.species});
}

String _clean(String? v) => (v == null || v.trim().isEmpty) ? '—' : v.trim();

int _accumulate(_Node n) {
  if (n.children.isEmpty) return n.leaves;
  var total = 0;
  for (final c in n.children.values) {
    total += _accumulate(c);
  }
  n.leaves = total;
  return total;
}

_Node _buildTree(List<Species> list) {
  final root = _Node('All', 0, '');
  for (final s in list) {
    final g = s.majorGroup;
    final labels = <String>[
      g,
      _clean(s.taxonomy.order),
      _clean(s.taxonomy.family),
      _clean(s.taxonomy.genus),
    ];
    var node = root;
    for (var i = 0; i < labels.length; i++) {
      node = node.children
          .putIfAbsent(labels[i], () => _Node(labels[i], i + 1, g));
    }
    node.children.putIfAbsent(
      s.id,
      () => _Node(s.commonName, labels.length + 1, g,
          speciesId: s.id, species: s),
    ).leaves = 1;
  }
  _accumulate(root);
  return root;
}

// --- Layout ----------------------------------------------------------------

const int _maxRings = 3; // rings drawn beyond the focus before you must zoom

class _Arc {
  final _Node node;
  final double start; // radians
  final double sweep; // radians
  final int ring; // 1.._maxRings
  _Arc(this.node, this.start, this.sweep, this.ring);
}

List<_Arc> _layout(_Node focus) {
  final arcs = <_Arc>[];
  void rec(_Node n, double start, double sweep, int ring) {
    if (ring > 0) arcs.add(_Arc(n, start, sweep, ring));
    if (ring >= _maxRings || n.leaves == 0) return;
    final kids = n.children.values.toList()
      ..sort((a, b) => b.leaves.compareTo(a.leaves));
    var a = start;
    for (final c in kids) {
      final cs = sweep * (c.leaves / n.leaves);
      rec(c, a, cs, ring + 1);
      a += cs;
    }
  }

  rec(focus, -math.pi / 2, 2 * math.pi, 0);
  return arcs;
}

// --- Colour ----------------------------------------------------------------

const Map<String, Color> _groupColors = {
  'Mammals': Color(0xFF8D6E63),
  'Birds': Color(0xFF4F8FBA),
  'Reptiles': Color(0xFF66A05A),
  'Amphibians': Color(0xFF26A69A),
  'Fish': Color(0xFF2996C8),
  'Invertebrates': Color(0xFF9664AA),
};

Color _colorFor(_Node n) {
  final base = _groupColors[n.group] ?? const Color(0xFF8A8A8A);
  final hsl = HSLColor.fromColor(base);
  final l = (hsl.lightness + (n.depth - 1) * 0.07).clamp(0.30, 0.86).toDouble();
  return hsl.withLightness(l).toColor();
}

String _rankLabel(int depth) => switch (depth) {
      1 => 'Group',
      2 => 'Order',
      3 => 'Family',
      4 => 'Genus',
      5 => 'Species',
      _ => '',
    };

// --- Widget ----------------------------------------------------------------

class _TaxonomyTreeViewState extends State<TaxonomyTreeView> {
  late _Node _root;
  late List<_Node> _path; // breadcrumb; last entry is the focus

  // Geometry from the latest build, used for hit-testing taps.
  Offset _center = Offset.zero;
  double _rc = 0, _rw = 0, _r = 0;
  List<_Arc> _arcs = const [];

  @override
  void initState() {
    super.initState();
    _rebuild();
  }

  @override
  void didUpdateWidget(covariant TaxonomyTreeView old) {
    super.didUpdateWidget(old);
    _rebuild();
  }

  void _rebuild() {
    _root = _buildTree(widget.species);
    _path = [_root];
  }

  _Node get _focus => _path.last;

  void _tapNode(_Node n) {
    if (n.species != null) {
      widget.onOpenSpecies(n.species!);
    } else if (n.children.isNotEmpty) {
      setState(() => _path = [..._path, n]);
    }
  }

  void _onTap(Offset p) {
    final d = p - _center;
    final r = d.distance;
    if (r < _rc) {
      if (_path.length > 1) setState(() => _path = _path.sublist(0, _path.length - 1));
      return;
    }
    if (r > _r) return;
    final ring = ((r - _rc) / _rw).floor() + 1;
    if (ring < 1 || ring > _maxRings) return;
    final ang = math.atan2(d.dy, d.dx);
    for (final a in _arcs) {
      if (a.ring != ring) continue;
      var delta = (ang - a.start) % (2 * math.pi);
      if (delta < 0) delta += 2 * math.pi;
      if (delta < a.sweep) {
        _tapNode(a.node);
        return;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.species.isEmpty) {
      return const Center(child: Text('No sightings yet.'));
    }
    final focus = _focus;
    final arcs = _layout(focus);

    return LayoutBuilder(
      builder: (context, cons) {
        final side = math.min(cons.maxWidth, 360.0);
        final center = Offset(side / 2, side / 2);
        final radius = side / 2 - 8;
        final rc = radius * 0.30;
        final rw = (radius - rc) / _maxRings;

        // stash for hit-testing
        _center = center;
        _rc = rc;
        _rw = rw;
        _r = radius;
        _arcs = arcs;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _breadcrumb(),
            const SizedBox(height: 8),
            Center(
              child: SizedBox(
                width: side,
                height: side,
                child: GestureDetector(
                  onTapUp: (d) => _onTap(d.localPosition),
                  child: Stack(
                    children: [
                      CustomPaint(
                        size: Size(side, side),
                        painter: _SunburstPainter(
                          arcs: arcs,
                          center: center,
                          rc: rc,
                          rw: rw,
                          focusColor: focus.depth == 0
                              ? const Color(0xFF6E6E6E)
                              : _colorFor(focus),
                        ),
                      ),
                      Positioned.fromRect(
                        rect: Rect.fromCircle(center: center, radius: rc),
                        child: _centerLabel(focus, rc),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Divider(height: 1),
            Expanded(child: _legend(focus)),
          ],
        );
      },
    );
  }

  Widget _breadcrumb() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        children: [
          for (var i = 0; i < _path.length; i++) ...[
            if (i > 0)
              const Icon(Icons.chevron_right, size: 18),
            TextButton(
              style: TextButton.styleFrom(
                minimumSize: Size.zero,
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
              onPressed: () =>
                  setState(() => _path = _path.sublist(0, i + 1)),
              child: Text(_path[i].depth == 0 ? 'All' : _path[i].label),
            ),
          ],
        ],
      ),
    );
  }

  Widget _centerLabel(_Node focus, double rc) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(rc * 0.22),
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                focus.depth == 0 ? 'All' : focus.label,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 2),
              Text('${focus.leaves} species',
                  style:
                      const TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _legend(_Node focus) {
    final kids = focus.children.values.toList()
      ..sort((a, b) => b.leaves.compareTo(a.leaves));
    return ListView.separated(
      itemCount: kids.length,
      separatorBuilder: (_, _) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final n = kids[i];
        final isSpecies = n.species != null;
        return ListTile(
          leading: Container(
            width: 14,
            height: 14,
            decoration:
                BoxDecoration(color: _colorFor(n), shape: BoxShape.circle),
          ),
          title: Text(n.label, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(_rankLabel(n.depth)),
          trailing: isSpecies
              ? const Icon(Icons.chevron_right)
              : Text('${n.leaves}',
                  style: Theme.of(context).textTheme.titleMedium),
          onTap: () => _tapNode(n),
        );
      },
    );
  }
}

class _SunburstPainter extends CustomPainter {
  final List<_Arc> arcs;
  final Offset center;
  final double rc;
  final double rw;
  final Color focusColor;

  _SunburstPainter({
    required this.arcs,
    required this.center,
    required this.rc,
    required this.rw,
    required this.focusColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final stroke = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    // centre disc (the current focus)
    canvas.drawCircle(center, rc, Paint()..color = focusColor);
    canvas.drawCircle(center, rc, stroke);

    for (final a in arcs) {
      final innerR = rc + (a.ring - 1) * rw;
      final outerR = rc + a.ring * rw;
      final path = _annular(center, innerR, outerR, a.start, a.sweep);
      canvas.drawPath(path, Paint()..color = _colorFor(a.node));
      canvas.drawPath(path, stroke);
    }
  }

  Path _annular(
      Offset c, double innerR, double outerR, double start, double sweep) {
    final p = Path();
    final outRect = Rect.fromCircle(center: c, radius: outerR);
    final inRect = Rect.fromCircle(center: c, radius: innerR);
    final end = start + sweep;
    final pi0 = c + Offset(math.cos(start), math.sin(start)) * innerR;
    final po0 = c + Offset(math.cos(start), math.sin(start)) * outerR;
    final pi1 = c + Offset(math.cos(end), math.sin(end)) * innerR;
    p.moveTo(pi0.dx, pi0.dy);
    p.lineTo(po0.dx, po0.dy);
    p.arcTo(outRect, start, sweep, false);
    p.lineTo(pi1.dx, pi1.dy);
    p.arcTo(inRect, end, -sweep, false);
    p.close();
    return p;
  }

  @override
  bool shouldRepaint(covariant _SunburstPainter old) =>
      old.arcs != arcs || old.center != center || old.focusColor != focusColor;
}
