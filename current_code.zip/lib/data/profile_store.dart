import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../models/profile.dart';

/// Reactive, persisted local profile. Created with defaults on first launch
/// (which fixes the "joined" date); later there'll be edit methods to change
/// the display name, username, and avatar.
class ProfileStore {
  ProfileStore._();

  static const String boxName = 'profile';
  static const String _key = 'profile';

  static final ValueNotifier<Profile> current = ValueNotifier<Profile>(
    Profile.initial(DateTime.fromMillisecondsSinceEpoch(0)),
  );

  static Box get _box => Hive.box(boxName);

  static Future<void> init() async {
    final raw = _box.get(_key);
    if (raw is Map) {
      current.value = Profile.fromMap(raw);
    } else {
      final created = Profile.initial(DateTime.now());
      current.value = created;
      await _box.put(_key, created.toMap());
    }
  }

  static Future<void> save(Profile profile) async {
    current.value = profile;
    await _box.put(_key, profile.toMap());
  }
}
